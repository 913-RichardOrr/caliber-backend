exports.handler = async (event) => {
  // TODO implement

  const response = {
    statusCode: 200,

    body: JSON.stringify('CloudFormation deployment successful!'),
  };

  return response;
};
